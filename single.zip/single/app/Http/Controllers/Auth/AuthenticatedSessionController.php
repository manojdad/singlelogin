<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\Auth\LoginRequest;
use App\Models\User;
use App\Providers\RouteServiceProvider;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\View\View;

class AuthenticatedSessionController extends Controller
{
    /**
     * Display the login view.
     */
    public function create(): View
    {
        return view('auth.login');
    }

    /**
     * Handle an incoming authentication request.
     */
    public function store(LoginRequest $request): RedirectResponse
    {

        
      $user = User::whereEmail($request->email)->first();  // Get user by email address
      
      if (!$user || !Hash::check($request->password, $user->password)) {   // Check if user exists and password is correct
        // dd('test');
        $request->authenticate();
    }else{

        $user = User::where('email', $request->input('email'))->first(); // get user by email
    
        // Check if there is an active session for the user
        if ($user->session_id!=null ) {
            // Redirect with error message if there is an active session
            $request->flash();
            return redirect('/login')->with('error', 'Account has been logged in from another device.');
        }
       
    }
    
  

        
        $request->authenticate();

        $request->session()->regenerate();
        $user->update([
            'session_id' => session()->getId()
        ]);

        return redirect()->intended(RouteServiceProvider::HOME);
    }


    function  logoutother(Request $request)
    {
        // dd('logout');
        $user=User::where( 'email',$request->input('email') )->first();    //get current logged user id
        $user->update([                               //update session_id to null when logging out
           'session_id' => null,
        ]);
        return redirect('/login')->with('success', 'Account has been logged in from another device.');
        

    }

    /**
     * Destroy an authenticated session.
     */
    public function destroy(Request $request): RedirectResponse
    {

        $user=Auth::user();

        $user->update([                               //update session_id to null when logging out
            'session_id' => null,
         ]);
        Auth::guard('web')->logout();

        $request->session()->invalidate();

        $request->session()->regenerateToken();

        return redirect('/');
    }
}
